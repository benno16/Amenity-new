/**
 */
package general;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Adaptable Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see general.GeneralPackage#getAdaptableClass()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface AdaptableClass extends EObject {
} // AdaptableClass
