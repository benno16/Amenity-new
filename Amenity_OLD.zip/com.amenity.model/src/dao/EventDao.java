/**
 */
package dao;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event Dao</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dao.DaoPackage#getEventDao()
 * @model
 * @generated
 */
public interface EventDao extends GenericDao {
} // EventDao
