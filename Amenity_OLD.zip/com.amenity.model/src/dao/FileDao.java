/**
 */
package dao;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>File Dao</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dao.DaoPackage#getFileDao()
 * @model
 * @generated
 */
public interface FileDao extends GenericDao {
} // FileDao
