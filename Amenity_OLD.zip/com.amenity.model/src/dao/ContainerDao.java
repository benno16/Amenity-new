/**
 */
package dao;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Container Dao</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dao.DaoPackage#getContainerDao()
 * @model
 * @generated
 */
public interface ContainerDao extends GenericDao {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setOwner(Object user);
} // ContainerDao
