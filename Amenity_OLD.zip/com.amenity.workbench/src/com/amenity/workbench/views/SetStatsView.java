package com.amenity.workbench.views;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

public class SetStatsView extends ViewPart {

	public SetStatsView() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void createPartControl(Composite parent) {

		
	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub

	}

}
