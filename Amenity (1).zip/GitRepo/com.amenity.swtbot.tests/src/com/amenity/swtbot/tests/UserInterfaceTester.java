package com.amenity.swtbot.tests;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class UserInterfaceTester {

	@Test
	public void test() {
		assertTrue(true);
	}
}
